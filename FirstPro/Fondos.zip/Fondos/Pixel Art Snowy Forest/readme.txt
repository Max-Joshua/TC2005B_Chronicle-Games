
 Thank you for buy my Pixel art snowy forest!

 Feel free to send me messages or leave a comment if you have questions or need more info.


 *Info

   Artwork created by Eder Muniz

   Pixel Art Infinite Runner Pack

   PNG, PSD Formats



 *Contents

   PNG Folder
   Contains all the layers ready to use in PNG Format

   PREVIEWS
   Flattened HD Res example PNG and gif files

   PSD
   Working Photoshop format files for editing.

